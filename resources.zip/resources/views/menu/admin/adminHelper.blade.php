  <div class="col-12 mb-4  ">
      <div class=" bg-white p-4 rounded-2 me-3 ms-3">
          <i class="fa-solid fa-key fa-bounce fa-2xl"></i>
          Anda sedang berada di mode Admin! <strong class="text-primary">{{ Auth::user()->name }}</strong>
      </div>
  </div>
